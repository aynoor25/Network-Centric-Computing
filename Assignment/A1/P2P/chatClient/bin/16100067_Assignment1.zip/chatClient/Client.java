//package chatClient;

import java.util.*;
import java.net.*;
import java.io.*;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Takes command line arguments
				//int port = Integer.parseInt(args[1]);
				//String ip = args[0];
				int port = 4321;
				String ip = "localhost";
				Socket sock = null;
				try {
					// Connect to the given IP and Port and store in the sock variable
					sock = new Socket(ip, port);
					System.out.println("Connected to server.");
					/* Next, it creates a PrintWriter object to send data over 
					 * the socket connection to the server program. 
					 * It also creates a BufferedReader object to read the text 
					 * sent by the server back to the client.*/
					// Taking input from socket
					//InputStreamReader isr = new InputStreamReader(sock.getInputStream());
					//BufferedReader br = new BufferedReader(isr);
					PrintWriter output = new PrintWriter(new OutputStreamWriter(System.out));
					output.println("whatever");
					// The following is a blocking call
					System.out.println("hiiiiiiiiii");
					//String input;
					//while ((input = br.readLine()) != null) {
						//System.out.println(input);
					//}
					
					
					
					/*BufferedReader clientInput = new BufferedReader(new InputStreamReader(System.in));
					String messageToServer = clientInput.readLine();
					// send message to server
					OutputStream os = sock.getOutputStream();
					OutputStreamWriter o = new OutputStreamWriter(os);
					BufferedWriter bwriter = new BufferedWriter(o);
					//String messageToServer = "1";
					bwriter.write(messageToServer);
					bwriter.flush();
					System.out.println("Message sent to server " + messageToServer);*/
					// receive message from server
					InputStream in = sock.getInputStream();
					InputStreamReader ir = new InputStreamReader(in);
					BufferedReader breader = new BufferedReader(ir);
					String messageReceived;
					while ((messageReceived = breader.readLine()) != null) {
						//System.out.println("Message received from server "+messageReceived);
						System.out.println(messageReceived);
					}
					
					//while(true) {
						
					//}
				} catch (Exception e) {
					// Exception printed on console in case of error
					e.printStackTrace();
				}
	}
	
	String[] ips;				// stores IP addresses
	
	public String lookup(String filename) {
		String[][] array  = new String[5][6];			// array is the clientsPresent array in server class
		for (int i = 0; i < array[0].length; i++) {
			for (int j = 0; j < array[1].length; j++) {
				if (array[i][j] == filename) {
					return ips[i];
				}
			}
		}
		return null;
	}
	
	public long get(String filename, long IPaddress, Socket sock) throws IOException{
		String[][] array  = new String[5][6];			// array is the clientsPresent array in server class
		String receiveFile = "C:/output.txt";		// initialize to path
		boolean found = false;;
		String ip = "111";				// don't initialize
		for (int i = 0; i < array[0].length; i++) {
			for (int j = 0; j < array[1].length; j++) {
				if (array[i][j] == filename) {
					// copy into local repo
					//return 1;
					found = true; ip = findIP(i);
					receiveFile = array[i][j];
					break;
				}
				if (found) break;
			}
		}
		int port = 4562;
		if (found == true) {
			int sizeOfFile = 5420000;			///assumed; should larger than required
			FileOutputStream f = null;
			BufferedOutputStream b = null;
			try {
				sock = new Socket(ip, port);
				System.out.println("Connecting to server...");
				
				InputStream in = sock.getInputStream();
				f = new FileOutputStream(receiveFile);
				b = new BufferedOutputStream(f);
				byte[] byteArray = new byte[sizeOfFile];
				int readBytes = in.read(byteArray,0,byteArray.length);
				int curr = readBytes;		// number of bytes read
				do {
					readBytes = in.read(byteArray, curr, (byteArray.length-curr));
					if (readBytes>=0) {
						curr = curr+readBytes;
					}
				} while(readBytes>-1);
				b.write(byteArray, 0, curr);
				b.flush();
				System.out.println("File "+receiveFile+"downloaded ("+curr+" bytes read)");
			} finally {
				//if (sock != null) sock.close(); 
				if (b != null)  b.close();
				if (f != null) f.close();
			}
		}
		if (found == false) return -1;
		return -1;
	}
	
	public int put(String filename, String data, Socket sock) throws IOException {
		try {
			File newFile = new File(filename);
			// send message to server
			OutputStream os = sock.getOutputStream();
			OutputStreamWriter o = new OutputStreamWriter(os);
			BufferedWriter bwriter = new BufferedWriter(o);
			String messageToServer = "1";
			bwriter.write(messageToServer);
			bwriter.flush();
			System.out.println("Message sent to server " + messageToServer);
			// receive message from server
			InputStream in = sock.getInputStream();
			InputStreamReader ir = new InputStreamReader(in);
			BufferedReader breader = new BufferedReader(ir);
			String messageReceived = breader.readLine();
			System.out.println("Message received from server "+messageReceived);
		} catch (Exception e) {
			// Exception printed on console in case of error
			e.printStackTrace();
		}
		return 1;
	}
	
	
	public  String findIP(int ip) {
		return ips[ip];
	}
}
