package chatClient;

import java.util.List;

public class trying {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List[ ][ ] clientsPresent = new List[5][6];
		System.out.println(clientsPresent[1].length); 
	}

}
