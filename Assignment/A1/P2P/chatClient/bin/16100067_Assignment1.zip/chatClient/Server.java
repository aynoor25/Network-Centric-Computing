//package chatClient;

import java.util.*;
import java.net.*;
import java.io.*;

public  class Server {
	static List<String[]> clientsPresent = new ArrayList<String[]>();			// stores the files kept with clients 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Port number taken from command line and converted to integer
				//int port = Integer.parseInt(args[0]);
				int port = 4321;
				int cases = 0;
				String messageClient = "";
				Socket client = null;
				try {
					// Start listening for connection on the specified port
					ServerSocket server = new ServerSocket(port);
					System.out.println("Starting server.");
					while (true) {
						//System.out.println("hi");
						// The following is a blocking call
						client = server.accept();
						//System.out.println("yo");
						// Send message to the connected client
						// to print on console
						// client.getOutputStream outputs to clients console
						PrintWriter pw = new PrintWriter(client.getOutputStream(), true);
						pw.println("Hello from server.");
						pw.println("Please choose from the following options:");
						pw.println("1. Register Client");
						// Read message from the client
						InputStreamReader isr = new InputStreamReader(client.getInputStream());
						BufferedReader br = new BufferedReader(isr);
						
						// The following is a blocking call
						String message = br.readLine();
						System.out.println(message);
						//cases = (int)message;
						
						//reading message from client
						client = server.accept();
		                InputStream in = client.getInputStream();
		                InputStreamReader ir = new InputStreamReader(in);
		                BufferedReader breader = new BufferedReader(ir);
		                messageClient = breader.readLine();
		                System.out.println("Message received from client is "+ messageClient);
		               //Sending a reply to client
		                String reply = "Done.";
		                OutputStream out = client.getOutputStream();
		                OutputStreamWriter ow = new OutputStreamWriter(out);
		                BufferedWriter bwriter = new BufferedWriter(ow);
		                bwriter.write(reply);
		                System.out.println("Message sent to the client is "+ reply);
		                bwriter.flush();
					}
				} catch (Exception e) {
					// Exception printed on console in case of error
					e.printStackTrace();
				}		
				// cases to handle different requests
				if (messageClient != "") {
					cases = Integer.parseInt(messageClient);
				} else {cases = 0;}
				switch(cases) {
				case 1: 
					InetAddress address = client.getInetAddress();
					String client_name = address.getHostName();
					addClient(client_name);
					break;
				default:
					System.out.println("Invalid input");
					break;
				}
				
	}
	public static void addClient(String clientName) {
		clientsPresent.add(new String[] {clientName});
	}
}
