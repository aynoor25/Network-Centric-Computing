public class Admin implements Runnable {

	// Whatever is inside the run method will be executed when the thread starts
	public void run() {
		while (true)
			System.out.println("From admin.");
	}
}